<!DOCTYPE html>
<html>

<head>
    <title>Contact - Fix Blog</title>
    <?php include_once('include/common.php'); ?>
</head>

<body>
    <?php include_once('include/header.php'); ?>
    <header class="masthead" style="background-image:url('assets/img/contact-bg.jpg');">
        <div class="overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-lg-8 mx-auto position-relative">
                    <div class="site-heading">
                        <h1>Contact Us</h1><span class="subheading">Have questions? I have answers.</span>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-lg-8 mx-auto">
                <p>Want to get in touch? Fill out the form below to send me a message and I will get back to you as soon as possible!</p>
                <form id="contactForm" name="sentMessage" novalidate="novalidate" action="success.php" method="post">
                    <div class="control-group">
                        <div class="form-floating controls mb-3">
                            <input class="form-control" type="text" id="name" name="name" placeholder="Name" required >
                            <label class="form-label" for="name">Name</label>
                            <small class="form-text text-danger help-block"></small>
                        </div>
                    </div>
                    <div class="control-group">
                        <div class="form-floating controls mb-3">
                            <input class="form-control" type="email" id="email" name="email" placeholder="Email Address" required>
                            <label class="form-label">Email Address</label>
                            <small class="form-text text-danger help-block"></small>
                        </div>
                    </div>
                    <div class="control-group">
                        <div class="form-floating controls mb-3">
                            <input class="form-control" type="text" id="subject" name="subject" placeholder="Subject" required>
                            <label class="form-label">Subject</label>
                            <small class="form-text text-danger help-block"></small>
                        </div>
                    </div>
                    <div class="control-group">
                        <div class="form-floating controls mb-3">
                            <textarea class="form-control" id="message" name="message" required placeholder="Message" style="height: 150px;"></textarea>
                            <label class="form-label">Message</label>
                            <small class="form-text text-danger help-block"></small>
                        </div>
                    </div>
                    <div id="success"></div>
                    <div class="mb-3">
                        <input class="btn btn-primary" id="sendMessageButton" type="submit" value="Send">
                    </div>
                </form>
            </div>
        </div>
    </div>
    <hr>
    <?php include_once('include/footer.php'); ?>
</body>

</html>