<footer>
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-lg-8 mx-auto">
                <ul class="list-inline text-center">
                    <li class="list-inline-item"><span class="fa-stack fa-lg"><i class="fa fa-circle fa-stack-2x"></i><i class="fa fa-twitter fa-stack-1x fa-inverse"></i></span></li>
                    <li class="list-inline-item"><span class="fa-stack fa-lg"><i class="fa fa-circle fa-stack-2x"></i><i class="fa fa-facebook fa-stack-1x fa-inverse"></i></span></li>
                    <li class="list-inline-item"><span class="fa-stack fa-lg"><i class="fa fa-circle fa-stack-2x"></i><i class="fa fa-github fa-stack-1x fa-inverse"></i></span></li>
                </ul>
                <p class="text-muted copyright">Copyright&nbsp;©&nbsp;Fix Blog 2023</p>
            </div>
        </div>
    </div>
</footer>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>
<script src="assets/js/clean-blog.js"></script>

<script>
  // Fetch the articles data from the JSON file
  fetch('articles.json')
    .then(response => response.json())
    .then(data => {
      const articles = data.articles;
      const articlesList = document.getElementById('articles-list');

      if(articlesList){
        for (let i = 0; i < articles.length; i++) {
            const article = articles[i];

            const words = article.description.split(" ");
            const limit = 15;
            const description = words.slice(0, limit).join(" ");

            const html = `
                <div class="card mb-4">
                    <img class="card-img-top" src="${article.image}" alt="${article.title}">
                    <div class="card-body">
                        <h2 class="card-title post-title">${article.title}</h2>
                        <h3 class="card-subtitle mb-2 text-muted post-subtitle">${description}...</h3>
                        <p class="card-text">By <a href="#">${article.author}</a> on ${format_date(article.date)}</p>
                        <a href="single_post.php?id=${article.id}" class="btn btn-xs btn-info">Read More</a>
                    </div>
                </div>
            `;

            const card = document.createElement('div');
            card.classList.add('col-md-6');
            card.innerHTML = html.trim();

            articlesList.appendChild(card);
        }
      }
    })
    .catch(error => {
      console.error('Error fetching articles:', error);
    });

    const urlParams = new URLSearchParams(window.location.search);
    const articleId = urlParams.get('id');
    const articleContainer = document.getElementById('article-container');

    if(articleContainer){
        fetch('articles.json')
        .then(response => response.json())
        .then(data => {
            const articles = data.articles;
            const article = articles.find(article => article.id === parseInt(articleId));
            if (article) {
            const articleHtml = `
                <header class="masthead" style="background-image:url('${article.image}');">
                    <div class="overlay"></div>
                    <div class="container">
                        <div class="row">
                            <div class="col-md-10 col-lg-8 mx-auto position-relative">
                                <div class="post-heading">
                                    <h1>${article.title}</h1>
                                    <span class="meta">By&nbsp;<a href="#">${article.author}</a>&nbsp;on ${format_date(article.date)}</span>                    </div>
                            </div>
                        </div>
                    </div>
                </header>
                <article>
                    <div class="container">
                        <div class="row" id="articles-description">
                        ${article.description}
                        </div>
                    </div>
                </article>
            `;

            articleContainer.innerHTML = articleHtml;
            } else {
                console.error(`Article not found.`);
            }
        })
        .catch(error => {
            console.error('Error fetching articles:', error);
        });
    }

    function format_date(datestr, format={ month: 'long', day: 'numeric', year: 'numeric' }){
        const date = new Date(datestr);
        const formattedDate = date.toLocaleDateString('en-US', format);
        return formattedDate;
    }
</script>