<!DOCTYPE html>
<html>
    <head>
        <title>Home - Fix Blog</title>
        <?php include_once('include/common.php'); ?>
    </head>

    <body>
        <?php include_once('include/header.php'); ?>
        <div id="article-container">
        
        </div>
        <?php include_once('include/footer.php'); ?>
    </body>
</html>