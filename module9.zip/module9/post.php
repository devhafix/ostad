<!DOCTYPE html>
<html>
    <head>
        <title>Home - Fix Blog</title>
        <?php include_once('include/common.php'); ?>
    </head>

    <body>
        <?php include_once('include/header.php'); ?>
        <header class="masthead" style="background-image:url('assets/img/post-bg.jpg');">
            <div class="overlay"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-10 col-lg-8 mx-auto position-relative">
                        <div class="post-heading">
                            <h1>Man must explore, and this is exploration at its greatest</h1>
                            <h2 class="subheading">Problems look mighty small from 150 miles up</h2>
                            <span class="meta">By&nbsp;<a href="#">Jane Doe</a>&nbsp;on August 24, 2022</span>                    </div>
                    </div>
                </div>
            </div>
        </header>
        <article>
            <div class="container">
                <h1>Blog Posts</h1>
                <div class="row" id="articles-list">
                        
                </div>
            </div>
        </article>
        
        <?php include_once('include/footer.php'); ?>
    </body>

</html>